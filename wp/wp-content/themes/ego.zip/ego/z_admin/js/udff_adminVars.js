
/*-------------------------------------------------------------------------

Theme Name: SQUARED - version 1.0

For any questions concerning this theme please contact us through our 
profile page at themeforest.

-------------------------------------------------------------------------*/

//THEME SETUP//////////////////////////////////////////////////////////////

/*init-------------------------------------------------------------------*/

var startPage = "1"						//page to display upon loading


var hoverFadeSpeed = 'fast'  			//Portfolio/icons hover speed - Possible values: 'slow', 'normal', 'fast', or in milliseconds
var pageFadeSpeed = 400					//Page fade speed
var menuEase = 'easeInCubic'			//Ease type
var contentToggleSpeed = 'normal'		//Content toggle speed
var pageEase = 'easeInCubic'			//Ease type
var isIOS = false;